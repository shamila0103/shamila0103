# GNGbotnet
- GNG BOTNET BY CRYPTONITE -

                          
                    
                       / ____| \ | |/ ____|
                      | |  __|  \| | |  __ 
                      | | |_ | . ` | | |_ |
                      | |__| | |\  | |__| |
                       \_____|_| \_|\_____|
                      
  
     GNG botnet v1.0 - გადოსე და იბატონე!
            ===== ვერსია: [ Private ] ======
            
# Methods/მეთოდები

layer7 - layer4


 $ 0: სახლი[ HOME ] 
 
 
 $ 1: Proxy შეტევა[ DDoS ] 
 
 
 $ 2: Socks შეტევა[ DDoS ]   
 
 
 $ 3: JS-Normal[ Home ]      
 
 
 $ 4: Raw-DoS[ Home ]            
 
 
 $ 5: UDP გაფლუდვა[ Home ] 
 
 
 $ 6: TCP-SYN Flood[ გაფლუდვა ]








.


# Activate/აქტივაცია

python3 gng.py


![photo_2022-02-21_11-20-06](https://user-images.githubusercontent.com/100119969/154918372-3c6bc82c-0e0a-4271-b882-59b31effecef.jpg)


